package ca.flearning.restfulgloom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulGloomApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulGloomApplication.class, args);
	}

}
