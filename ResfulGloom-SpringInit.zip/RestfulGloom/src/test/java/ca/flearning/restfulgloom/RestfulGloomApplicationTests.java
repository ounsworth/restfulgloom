package ca.flearning.restfulgloom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulGloomApplicationTests {

	@Test
	void contextLoads() {
	}

}
